void condicional() {
  bool? isActive;
  if (isActive == true) {
    print('la actividad es null');
  } else {
    print('No es null');
  }
}
