void empleados() {
// Strings
  final String nombre = 'Tony';
  final apellido = 'Stark';
// nombre = 'Peter';
  print('$nombre $apellido');
// Números
  int empleados = 10;
  double salario = 1856.25;
  print('numero de empleados $empleados');
  print('salario $salario');
}
