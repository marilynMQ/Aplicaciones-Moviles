//import 'package:flutter/material.dart';
//import 'package:tarea1/cmd/ejercicios/1.dart';
//import 'package:tarea1/cmd/ejercicios/2.dart';
//import 'package:tarea1/cmd/ejercicios/3.dart';

//import 'package:tarea1/cmd/ejercicios/lista.dart';

//import 'package:tarea1/cmd/ejercicios/map.dart';

//import 'package:tarea1/cmd/ejercicios/funcion.dart';

//import 'package:tarea1/cmd/ejercicios/clases_basic.dart';

//import 'package:tarea1/cmd/ejercicios/constructor.dart';

/*import 'package:tarea1/cmd/ejercicios/async_await.dart';
import 'package:tarea1/cmd/ejercicios/future.dart';
import 'package:tarea1/cmd/ejercicios/mixins.dart';*/

import 'package:tarea1/cmd/calculadora/calculadora.dart';

void main() {
  final calculadora = new calculator();

  print('la suma es ${calculadora.suma(5, 4)}');

  //saludo();
  //empleados();
  //condicional();
  //lista();
  //map();
  //funcion();
  //basica();
  //construc();
  //getset();
  //animales();
  //extend();
  //imprimir();
  //futuro();
  //prubea1();
}
